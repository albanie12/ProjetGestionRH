-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: gestion_rh
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2025-01-18 21:14:22.000368','2','AdenisHashani',1,'[{\"added\": {}}]',4,1),(2,'2025-01-18 21:14:44.340008','2','AdenisHashani',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\", \"Email address\"]}}]',4,1),(3,'2025-01-18 21:15:04.648734','1','Marketing',1,'[{\"added\": {}}]',7,1),(4,'2025-01-18 21:15:27.884072','1','Payslip for Adenis hashani - January 2025',1,'[{\"added\": {}}]',10,1),(5,'2025-01-19 10:39:48.996040','1','RH',1,'[{\"added\": {}}]',3,1),(6,'2025-01-19 10:40:28.371857','3','AyaMoumenMokhtary',1,'[{\"added\": {}}]',4,1),(7,'2025-01-19 10:40:50.697316','3','AyaMoumenMokhtary',2,'[{\"changed\": {\"fields\": [\"Groups\"]}}]',4,1),(8,'2025-01-19 10:41:42.226811','3','AyaMoumenMokhtary',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\", \"Email address\", \"Groups\", \"User permissions\"]}}]',4,1),(9,'2025-01-19 10:42:22.153347','2','IT',1,'[{\"added\": {}}]',7,1),(10,'2025-01-19 10:42:35.873180','3','Comptabilité',1,'[{\"added\": {}}]',7,1),(11,'2025-01-19 10:43:09.561430','4','RH',1,'[{\"added\": {}}]',7,1),(12,'2025-01-19 10:43:17.796872','5','Finance',1,'[{\"added\": {}}]',7,1),(13,'2025-01-19 10:48:02.017959','6','Data',1,'[{\"added\": {}}]',7,1),(14,'2025-01-19 10:49:24.611760','1','AyaMoumenMokhtary',1,'[{\"added\": {}}]',8,1),(15,'2025-01-19 10:49:47.623134','2','ArtHashani',1,'[{\"added\": {}}]',8,1),(16,'2025-01-19 10:50:15.429721','1','AyaMoumenMokhtary',2,'[{\"changed\": {\"fields\": [\"Salary\"]}}]',8,1),(17,'2025-01-19 10:50:40.019499','3','AdenisHashani',1,'[{\"added\": {}}]',8,1),(18,'2025-01-19 10:50:58.080228','1','AyaMoumenMokhtary',2,'[{\"changed\": {\"fields\": [\"Salary\"]}}]',8,1),(19,'2025-01-19 10:51:21.493408','1','Évaluation de Aya Moumen - 2025-01-19',1,'[{\"added\": {}}]',11,1),(20,'2025-01-19 10:51:37.067911','1','Évaluation de Aya Moumen - 2025-01-19',2,'[{\"changed\": {\"fields\": [\"Rating\", \"Feedback\"]}}]',11,1),(21,'2025-01-19 10:52:37.185248','2','Payslip for Aya Moumen - January 2025',1,'[{\"added\": {}}]',10,1),(22,'2025-01-19 13:38:59.534958','3','Payslip for  - January 2025',1,'[{\"added\": {}}]',10,1),(23,'2025-01-19 13:41:46.297389','1','ArtHashani',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\"]}}]',4,1),(24,'2025-01-19 13:42:05.492089','4','Payslip for Art Hashani - January 2025',1,'[{\"added\": {}}]',10,1),(25,'2025-01-19 13:42:13.864032','3','Payslip for Art Hashani - January 2025',3,'',10,1),(26,'2025-01-19 13:58:55.569522','2','Évaluation de Art Hashani - 2025-01-19',1,'[{\"added\": {}}]',11,1),(27,'2025-01-19 14:12:37.006037','4','ThibautAnani',1,'[{\"added\": {}}]',4,1),(28,'2025-01-19 17:01:22.735316','3','AyaMoumenMokhtary',2,'[{\"changed\": {\"fields\": [\"Active\", \"Staff status\"]}}]',4,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-19 21:19:38
